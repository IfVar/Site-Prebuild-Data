/* Variables */
    // Content Here

/* Event Listeners */
document.addEventListener("DOMContentLoaded", (event) => {
    // Script To Load Automatically Once Website Loads
});

/* Functions */
    // Content Here

/* Other Scripts */
    // Content Here
